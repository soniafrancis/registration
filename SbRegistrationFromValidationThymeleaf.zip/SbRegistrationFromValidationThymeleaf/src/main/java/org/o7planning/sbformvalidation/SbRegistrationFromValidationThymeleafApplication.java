package org.o7planning.sbformvalidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbRegistrationFromValidationThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbRegistrationFromValidationThymeleafApplication.class, args);
	}

}
